#-------------------------------------------------#
# Title: Working with Functions
# Dev:   Adrianne McAllister
# Date:  August 19, 2019
# ChangeLog: (Who, When, What)
#   Adrianne McAllister, 08/19/2019, Created Script

#-------------------------------------------------#

#-- Data --#
objFileName = "C:\_PythonClass\Assignment06\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

#-- Input/Output --#
# Declare classes
# Declare functions


class FileMethod(object):

    # Define the function
    @staticmethod
    def openfile():
        """"Reads through .txt file and returns data as a dictionary"""
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")
            dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()

    # Define the function
    @staticmethod
    def saveFile():
        """"Writes the data back to the .txt file"""
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press [Enter] to return to main menu")
        else:
            input("New data was NOT Saved, but previous data still exists! Press [Enter] to return to main menu")
        MenuMethod.mainMenu()

class MenuMethod(object):
    # Define the function
    @staticmethod
    def mainMenu():
        """"Loops through the menu"""
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
        while True:
            try:
                strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
                if (strChoice.strip() == "1"):
                    MenuMethod.printtoDoList()
                    break
                elif (strChoice.strip() == "2"):
                    MenuMethod.addTask()
                    break
                elif (strChoice.strip() == "3"):
                    MenuMethod.removeTask()
                    break
                elif (strChoice.strip() == "4"):
                    FileMethod.saveFile()
                    break
                elif (strChoice.strip() == "5"):
                    break
                else:
                    print("Choice not valid. Enter 1-5")
            except ValueError:
                print("Choice not valid. Enter 1-5")
        exit

    # Define the function
    @staticmethod
    def printtoDoList():
        """"Prints the current items"""
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        anykey = input("Enter any key to return to main menu")
        MenuMethod.mainMenu()

    # Define the function
    @staticmethod
    def addTask():
        """"Adds a task"""
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)
        MenuMethod.printtoDoList()
        anykey = input("Enter any key to return to main menu")
        MenuMethod.mainMenu()

    # Define the function
    @staticmethod
    def removeTask():
        """"Removes a task"""
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):
                del lstTable[intRowNumber]
                blnItemRemoved = True
            intRowNumber += 1
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")
        MenuMethod.printtoDoList()
        anykey = input("Enter any key to return to main menu")
        MenuMethod.mainMenu()

#-- Processing --#
#Call functions


FileMethod.openfile()

MenuMethod.mainMenu()