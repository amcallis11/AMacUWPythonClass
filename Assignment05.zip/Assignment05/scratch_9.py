

ObjFileName = open("Todo.txt", "w+")
ObjFileName.write("Clean House" "," "low\n")
ObjFileName.write("Pay Bills" "," "high\n")

with open("Todo.txt", "r") as ObjFileName:
    line1 = ObjFileName.readline()
    line2 = ObjFileName.readline()
    print(line1)
    print(line2)


dicRow1 = {"Task": line1[:11], "Priority": line1[12:15]}
dicRow2 = {"Task": line2[:9], "Priority": line2[10:14]}

print(dicRow1)

Table1 = [dicRow1, dicRow2]

print(Table1)

for line in ObjFileName:
    x = line.split(",")
    key = x[0]
    val = x[1]
    val1 = len(val)-1
    val = val[0:val1]
    dicRow[key] = val

"""
dictionary = {}
with open("Todo.txt", "r") as ObjFileName:
    for cnt, line in enumerate(ObjFileName):
        print("Line {}: {}".format(cnt, line))
"""

"""     
        key, value = line.strip().split(",")
        dictionary[key] = value
print(dictionary)
"""

"""
ObjFileName = open("Todo.txt", "r")

dicRow1 = {}
for line in ObjFileName:
    print(line)
    key, value = line.strip().split(",")
    dicRow1[key] = value
print(dicRow1)


strPriority = ""

for line in ObjFileName:
    dicRow1.append(line)

dicRow1 = {"Task": strName, "Priority": strPriority}
"""

with open("Todo.txt", "r") as ObjFileName:
    line1 = ObjFileName.readline()
    line2 = ObjFileName.readline()
    print(line1)
    print(line2)
"""

objFileName = "Todo.txt"


lstTable = []

dicRow = {}

objFileName = open("Todo.txt", "r+")
for line in objFileName:
    (val1,val2) = line.split(",")
    dicRow [str("Task")] = val1
    dicRow [str("Priority")] = val2

print(dicRow)

"""
dicRow = {}
with open("Todo.txt", "r+") as ObjFileName:
    for line1 in ObjFileName:
        key, val = line1.split(",")
        dicRow[key] = val
print(dicRow)
"""


"""
ObjFileName = open("Todo.txt", "r")
Dictionary = {}
for line in ObjFileName:
    Dictionary["Task"] = line
print(Dictionary)
"""